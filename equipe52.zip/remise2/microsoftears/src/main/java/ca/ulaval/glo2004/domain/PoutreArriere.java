package ca.ulaval.glo2004.domain;

public class PoutreArriere {
}

