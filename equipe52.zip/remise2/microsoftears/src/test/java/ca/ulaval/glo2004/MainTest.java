package ca.ulaval.glo2004;

import static com.google.common.truth.Truth.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Exemple de test unitaire utilisant JUnit et Google Truth. Vous n'avez pas a faire des tests dans le cadre de votre
 * projet. Par contre, il peut s'averer utile de faire quelques tests pour certaines method pour s'assurer qu'elle retourne
 * bien ce qu'elle devrait retourner
 */
public class MainTest
{
    /**
     * Exemple de test avec JUnit
     */
    @Test
    public void exempleDuneAssertionJUnit()
    {
        assertTrue( true );
        assertFalse(false);
    }

    /**
     * Exemple de test avec Google truth
     */
    @Test
    public void exempleDuneAssertionGoogleTruth() {
        assertThat(true).isTrue();
        assertThat(false).isFalse();
        assertThat(1).isEqualTo(1);
        assertThat('x').isNotEqualTo('y');
        assertThat(10).isGreaterThan(5);
    }
}
